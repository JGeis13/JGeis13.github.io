var SLCdiv = document.getElementById('SLC');

function clockDisplay(timezone,divName){
    var x = new Date();
    var hours = x.getUTCHours();
        if(timezone == "Mountain-Denver"){ // add case for MST based on date
            var hours = hours - 6;
            if(hours < 1){ var hours = 24 + hours}
        }
        if(timezone == "Mountain-Arizona"){ 
            var hours = hours - 7;
            if(hours < 1){ var hours = 24 + hours}
        }
        if(timezone == "Pacific"){ // add case for PST based on date
            var hours = hours - 5;
            if(hours < 1){ var hours = 24 + hours}
        }
    var mins = x.getUTCMinutes();
    if(mins < 10){var mins = '0' + mins;}
    var secs = x.getUTCSeconds();
    if(secs < 10){var secs = '0' + secs;}
    var month = x.getUTCMonth();
    var year = x.getUTCFullYear();
    var day = x.getUTCDate();
    var AmPm = "AM";
        if(hours > 11 && hours != 24){
            var AmPm = "PM";
        }
        if(hours > 12){
            var hours = hours - 12;
        }
    var div = document.getElementById(divName);
    div.innerText =  hours + ":" + mins + ":" + secs + " " + AmPm;
}

setInterval(clockDisplay,1000,"Mountain-Denver",'COS');
setInterval(clockDisplay,1000,"Pacific",'HEN');
setInterval(clockDisplay,1000,"Mountain-Denver",'MER');
setInterval(clockDisplay,1000,"Mountain-Denver",'PRI');
setInterval(clockDisplay,1000,"Pacific",'SAT');
setInterval(clockDisplay,1000,"Mountain-Arizona",'SCO');
setInterval(clockDisplay,1000,"Mountain-Denver",'SLC');
setInterval(clockDisplay,1000,"Mountain-Denver",'STG');
setInterval(clockDisplay,1000,"Mountain-Arizona",'TUS');

$('.containBox').click(function(){
    $(this).toggleClass('bigger');
});

var centerInfo = {
    'COS': {'trainingSeats': 23, 'productionSeats': 300},
    'HEN': {'trainingSeats': 23, 'productionSeats': 300},
    'MER': {'trainingSeats': 23, 'productionSeats': 300},
    'PRI': {'trainingSeats': 23, 'productionSeats': 300},
    'SAT': {'trainingSeats': 23, 'productionSeats': 300},
    'SCO': {'trainingSeats': 23, 'productionSeats': 300},
    'SLC': {'trainingSeats': 23, 'productionSeats': 300},
    'STG': {'trainingSeats': 23, 'productionSeats': 300},
    'TUS': {'trainingSeats': 23, 'productionSeats': 300},
}

function getWeather(zipcode, centerAbbrev){
    var zip = zipcode;
    var weatherAPI = 'http://api.apixu.com/v1/current.json?';
    var APIkey = 'f345dcc428fd4a0495e215311172304';

    $.getJSON( weatherAPI + 'key=' + APIkey + '&q=' + zip, function( data ) {
        var location =  data.location.name;
        var temp = data.current.temp_f;
        var refreshTime = data.location.localtime;
        var lastUpdate = data.current.last_updated;
        var condition = data.current.condition.text;
        var icontxt = data.current.condition.icon;
        var icon = "<img src='" + 'http://' + icontxt + "'>";
        var iconBox = "<div class='weatherIcon'>"+icon+"<span>"+Math.round(temp)+" &#8457</span></div>";
        console.log(location,temp,lastUpdate,condition);
        $('#' + centerAbbrev).parent().prepend(iconBox);
    });
} 

setInterval(getWeather,900000,80920,'COS');
setInterval(getWeather,900000,89074,'HEN');
setInterval(getWeather,900000,83642,'MER');
setInterval(getWeather,900000,84501,'PRI');
setInterval(getWeather,900000,78229,'SAT');
setInterval(getWeather,900000,85256,'SCO');
setInterval(getWeather,900000,84123,'SLC');
setInterval(getWeather,900000,84770,'STG');
setInterval(getWeather,900000,85711,'TUS');